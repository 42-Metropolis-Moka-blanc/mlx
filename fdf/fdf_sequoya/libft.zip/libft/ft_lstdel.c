/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbaum <rbaum@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/01/02 18:50:18 by rbaum             #+#    #+#             */
/*   Updated: 2015/01/02 18:50:34 by rbaum            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstdel(t_list **alst, void (*del)(void *, size_t))
{
	t_list *tmp;
	t_list *tmp2;

	if (!alst || !*alst)
		return ;
	tmp = *alst;
	while (tmp)
	{
		tmp2 = tmp->next;
		del(tmp->content, tmp->content_size);
		free (tmp);
		tmp = tmp2;
	}
	*alst = NULL;
}
